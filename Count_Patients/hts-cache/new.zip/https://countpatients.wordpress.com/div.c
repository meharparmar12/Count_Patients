<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<title>Page not found &#8211; Count_Patients</title>
<link rel='dns-prefetch' href='//s2.wp.com' />
<link rel='dns-prefetch' href='//s1.wp.com' />
<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Count_Patients &raquo; Feed" href="https://countpatients.wordpress.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Count_Patients &raquo; Comments Feed" href="https://countpatients.wordpress.com/comments/feed/" />
	<script type="text/javascript">
		/* <![CDATA[ */
		function addLoadEvent(func) {
			var oldonload = window.onload;
			if (typeof window.onload != 'function') {
				window.onload = func;
			} else {
				window.onload = function () {
					oldonload();
					func();
				}
			}
		}
		/* ]]> */
	</script>
			<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s0.wp.com\/wp-content\/mu-plugins\/wpcom-smileys\/twemoji\/2\/72x72\/","ext":".png","svgUrl":"https:\/\/s0.wp.com\/wp-content\/mu-plugins\/wpcom-smileys\/twemoji\/2\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/s2.wp.com\/wp-includes\/js\/wp-emoji-release.min.js?m=1516999477h&ver=4.9.7-alpha-43298"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56692,8205,9792,65039],[55357,56692,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='all-css-0-1' href='https://s1.wp.com/_static/??-eJx9j90KwjAMRl/IGhU38UJ8lrYLW7emDf1h7O3tHMp0sJuQfJzDR2Bkob1L6BJQFmxza1yEkbUnEclYnP6uo47xACtNWd9+RZJhwGRcK5QMUNDfZCOvOq0ZMEKPiaUexPvaw7UPWHJimWaCsDESLVLB9jTi+mPNa1e6dmuW35XigDGKMslkEqkrRVtviYGzgkYGCTFNFmfqSY9zdbne6vvpUvUvR66LKw==?cssminify=yes' type='text/css' media='all' />
<link rel='stylesheet' id='dara-fonts-css'  href='https://fonts.googleapis.com/css?family=Source+Sans+Pro%3A300%2C300italic%2C400%2C400italic%2C600%7CYrsa%3A300%2C400%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='all-css-2-1' href='https://s1.wp.com/_static/??-eJyNjuEOwiAMhF9IbKZz/jI+C7KKVaBklBDfXnQxwRgX/93l7rsWSlSGg2AQ8FlFly2FBBYDTlSDH3JtUlpBw8oFPSaI+QSjnjRQMJDk7lCVaNh/9ZtbhUaLkgBzTflGqJwuIOij01I3XzP/DCQ2pJ2af23NDBMEljl8i6VVi6wcGy3E4cOos9M0LaETnhzbKi3UVmOf0NEfut1mP2z7rh+uD+jJkCw=?cssminify=yes' type='text/css' media='all' />
<link rel='stylesheet' id='print-css-3-1' href='https://s2.wp.com/wp-content/mu-plugins/global-print/global-print.css?m=1465851035h&cssminify=yes' type='text/css' media='print' />
<link rel='stylesheet' id='all-css-4-1' href='https://s0.wp.com/_static/??/wp-content/mu-plugins/actionbar/actionbar.css,/wp-content/themes/h4/global.css?m=1516985148j&cssminify=yes' type='text/css' media='all' />
<script type='text/javascript' src='https://s0.wp.com/_static/??-eJyFztEKwjAMBdAfsquTiXsRv6XWOFKXtDbphn69HeiDMBQCgdzDJXZOBtmP5QJiQ517gfx4rybIxv4ChnDITqEh5A/2kRVYF0vxjCOYIpDdUG+16BpXXIqiBCIVraTfLyFPCPNfFkCT8zeTQfC5tJ7o2Hb9Yde3+24bXjRNW9I='></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://countpatients.wordpress.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://s1.wp.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress.com" />
<link rel="shortcut icon" type="image/x-icon" href="https://s1.wp.com/i/favicon.ico" sizes="16x16 24x24 32x32 48x48" />
<link rel="icon" type="image/x-icon" href="https://s1.wp.com/i/favicon.ico" sizes="16x16 24x24 32x32 48x48" />
<link rel="apple-touch-icon-precomposed" href="https://s2.wp.com/i/webclip.png" />
<link rel="search" type="application/opensearchdescription+xml" href="https://countpatients.wordpress.com/osd.xml" title="Count_Patients" />
<link rel="search" type="application/opensearchdescription+xml" href="https://s1.wp.com/opensearch.xml" title="WordPress.com" />
<meta name="theme-color" content="#db045a" />
<meta name="application-name" content="Count_Patients" /><meta name="msapplication-window" content="width=device-width;height=device-height" /><meta name="msapplication-task" content="name=Subscribe;action-uri=https://countpatients.wordpress.com/feed/;icon-uri=https://s1.wp.com/i/favicon.ico" /><meta name="msapplication-task" content="name=Sign up for a free blog;action-uri=http://wordpress.com/signup/;icon-uri=https://s1.wp.com/i/favicon.ico" /><meta name="msapplication-task" content="name=WordPress.com Support;action-uri=http://support.wordpress.com/;icon-uri=https://s1.wp.com/i/favicon.ico" /><meta name="msapplication-task" content="name=WordPress.com Forums;action-uri=http://forums.wordpress.com/;icon-uri=https://s1.wp.com/i/favicon.ico" /><style type="text/css" id="custom-background-css">
body.custom-background { background-color: #db045a; }
</style>
<style type="text/css" id="syntaxhighlighteranchor"></style>
<style type="text/css" id="custom-colors-css">#infinite-handle span,.hero-content-wrapper .cat-links a,.jetpack-social-navigation ul li,.jetpack-social-navigation ul a,.jetpack-social-navigation ul a:visited,.main-navigation,.main-navigation a,.main-navigation ul ul a,.button,.button:hover,.button:active,.button:focus,.menu-toggle,button,input[type=button],input[type=reset],input[type=submit],.woocommerce #respond input#submit.alt,.woocommerce a.button.alt,.woocommerce button.button.alt,.woocommerce input.button.alt,.woocommerce #respond input#submit.alt:hover,.woocommerce a.button.alt:hover,.woocommerce button.button.alt:hover,.woocommerce input.button.alt:hover{color:#fff}.jetpack-social-navigation ul a:hover,.menu-toggle:hover,.menu-toggle:focus{color:#fff}.site-footer,.site-footer a{color:#fff}body{background-color:#db045a}.site-footer{background-color:#ea0460}#secondary.widget-area .widget-title,.entry-title,.entry-title a,.featured-page .entry-title,.featured-page .entry-title a,.footer-widget-area .widget-title,.page-title,.site-title a,.woocommerce .page-title{color:#444}#infinite-handle span,.hero-content-wrapper .cat-links a,.jetpack-social-navigation ul li,.main-navigation,.main-navigation ul ul,.button,button,input[type=button],input[type=reset],input[type=submit],.woocommerce #respond input#submit.alt,.woocommerce a.button.alt,.woocommerce button.button.alt,.woocommerce input.button.alt,.woocommerce #respond input#submit.alt:hover,.woocommerce a.button.alt:hover,.woocommerce button.button.alt:hover,.woocommerce input.button.alt:hover{background-color:#db045a}input[type=email]:focus,input[type=password]:focus,input[type=search]:focus,input[type=text]:focus,input[type=url]:focus,textarea:focus{border-color:#db045a}.cat-links a,.comment-meta a,.entry-title a:active,.entry-title a:focus,.entry-title a:hover,.footer-widget-area a:active,.footer-widget-area a:focus,.footer-widget-area a:hover,.jetpack-testimonial-shortcode .testimonial-entry-title,.site-info a:active,.site-info a:focus,.site-info a:hover,a,body:not(.search):not(.single-jetpack-testimonial) .jetpack-testimonial .entry-title,body:not(.search):not(.single-jetpack-testimonial) .jetpack-testimonial .entry-title a{color:#db045a}</style>
</head>

<body class="error404 custom-background wp-custom-logo mp6 customizer-styles-applied hfeed no-sidebar not-multi-author display-header-text admin-bar highlander-enabled highlander-light">
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content">Skip to content</a>

	<header id="masthead" class="site-header" role="banner">

		
				<div class="site-branding">
			<a href="https://countpatients.wordpress.com/" class="custom-logo-link" rel="home" itemprop="url"><img width="500" height="500" src="https://countpatients.files.wordpress.com/2018/06/image.png" class="custom-logo" alt="Count_Patients" itemprop="logo" srcset="https://countpatients.files.wordpress.com/2018/06/image.png 500w, https://countpatients.files.wordpress.com/2018/06/image.png?w=150&amp;h=150 150w, https://countpatients.files.wordpress.com/2018/06/image.png?w=300&amp;h=300 300w" sizes="(max-width: 500px) 100vw, 500px" data-attachment-id="14" data-permalink="https://countpatients.wordpress.com/image/" data-orig-file="https://countpatients.files.wordpress.com/2018/06/image.png" data-orig-size="500,500" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&quot;:&quot;&quot;,&quot;focal_length&quot;:&quot;0&quot;,&quot;iso&quot;:&quot;0&quot;,&quot;shutter_speed&quot;:&quot;0&quot;,&quot;title&quot;:&quot;&quot;,&quot;orientation&quot;:&quot;0&quot;}" data-image-title="image" data-image-description="" data-medium-file="https://countpatients.files.wordpress.com/2018/06/image.png?w=300" data-large-file="https://countpatients.files.wordpress.com/2018/06/image.png?w=500" /></a>							<p class="site-title"><a href="https://countpatients.wordpress.com/" rel="home">Count_Patients</a></p>
			
					</div><!-- .site-branding -->

		<nav id="site-navigation" class="main-navigation" role="navigation">
	<button class="menu-toggle" aria-controls="top-menu" aria-expanded="false">Menu</button>
	<div class="menu-primary-container"><ul id="top-menu" class="menu"><li id="menu-item-6" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-6"><a href="/">Home</a></li>
</ul></div>	</nav>

	</header>

	
	<div id="content" class="site-content">

	<div class="content-wrapper without-featured-image">
		<div id="primary" class="content-area">
			<main id="main" class="site-main" role="main">
				<section class="error-404 not-found">
					<header class="page-header">
						<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
					</header>
					<div class="page-content">
						<p>It looks like nothing was found at this location. Maybe try a search?</p>

						<form role="search" method="get" class="search-form" action="https://countpatients.wordpress.com/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>					</div><!-- .page-content -->
				</section>
			</main><!-- .site-main -->
		</div><!-- .content-area -->
			</div><!-- .content-wrapper -->

	</div>

	
	<footer id="colophon" class="site-footer" role="contentinfo">
				<div class="site-info">
	<a href="https://wordpress.com/?ref=footer_blog">Blog at WordPress.com.</a>
	
	</div><!-- .site-info -->	</footer>
</div>
<!--  -->
<div id="wpadminbar" class="marketing-bar"><div class="marketing-bar-text">Create your website at WordPress.com</div><a class="marketing-bar-button" href="https://wordpress.com/?ref=marketing_bar">Get started</a></div><script type='text/javascript' src='//0.gravatar.com/js/gprofiles.js?ver=201824y'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var WPGroHo = {"my_hash":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://s1.wp.com/wp-content/mu-plugins/gravatar-hovercards/wpgroho.js?m=1380573781h'></script>

	<script>
		//initialize and attach hovercards to all gravatars
		jQuery( document ).ready( function( $ ) {

			if (typeof Gravatar === "undefined"){
				return;
			}

			if ( typeof Gravatar.init !== "function" ) {
				return;
			}			

			Gravatar.profile_cb = function( hash, id ) {
				WPGroHo.syncProfileData( hash, id );
			};
			Gravatar.my_hash = WPGroHo.my_hash;
			Gravatar.init( 'body', '#wp-admin-bar-my-account' );
		});
	</script>

		<div style="display:none">
	</div>
<div class="widget widget_eu_cookie_law_widget"><div
	class="hide-on-button ads-active"
	data-hide-timeout="30"
	data-consent-expiration="180"
	id="eu-cookie-law"
>
	<form method="post">
		<input type="submit" value="Close and accept" class="accept" />

		Privacy &amp; Cookies: This site uses cookies. By continuing to use this website, you agree to their use. <br />
To find out more, including how to control cookies, see here:
		<a href="https://automattic.com/cookies" >
			Cookie Policy		</a>
 </form>
</div>
</div><script type='text/javascript'>
/* <![CDATA[ */
var actionbardata = {"siteID":"147780500","siteName":"Count_Patients","siteURL":"http:\/\/countpatients.wordpress.com","icon":"<img alt='' src='https:\/\/s2.wp.com\/i\/logo\/wpcom-gray-white.png' class='avatar avatar-50' height='50' width='50' \/>","canManageOptions":"","canCustomizeSite":"","isFollowing":"","themeSlug":"pub\/dara","signupURL":"https:\/\/wordpress.com\/start\/","loginURL":"https:\/\/countpatients.wordpress.com\/wp-login.php","themeURL":"https:\/\/wordpress.com\/theme\/dara\/","xhrURL":"https:\/\/countpatients.wordpress.com\/wp-admin\/admin-ajax.php","nonce":"6d1d76c964","isSingular":"","isFolded":"","isLoggedIn":"","isMobile":"","subscribeNonce":"<input type=\"hidden\" id=\"_wpnonce\" name=\"_wpnonce\" value=\"de1b9fe1d1\" \/>","referer":"https:\/\/countpatients.wordpress.com\/div.c","canFollow":"","feedID":"83853504","statusMessage":"","customizeLink":"https:\/\/countpatients.wordpress.com\/wp-admin\/customize.php?url=https%3A%2F%2Fcountpatients.wordpress.com%2Fdiv.c","i18n":{"view":"View site","follow":"Follow","following":"Following","edit":"Edit","login":"Log in","signup":"Sign up","customize":"Customize","report":"Report this content","themeInfo":"Get theme: Dara","shortlink":"Copy shortlink","copied":"Copied","followedText":"New posts from this site will now appear in your <a href=\"https:\/\/wordpress.com\/\">Reader<\/a>","foldBar":"Collapse this bar","unfoldBar":"Expand this bar","editSubs":"Manage subscriptions","viewReader":"View site in Reader","viewReadPost":"View post in Reader","subscribe":"Sign me up","enterEmail":"Enter your email address","followers":"","alreadyUser":"Already have a WordPress.com account? <a href=\"https:\/\/countpatients.wordpress.com\/wp-login.php\">Log in now.<\/a>","stats":"Stats"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://s1.wp.com/_static/??-eJyVkM1uAjEMhF+I4IIEbQ+oz+JNzOLNb2Nnl8cne0GIw6q9jWbmG1mGpRibk1JSmAQczWyp3PeT7OAlis2U0EZOAoE9Cfw2anTD5ALV97LeKPZKaQM4rAgoQirrfMKZR1TO6e+MeC4mcPLmmm0Tc+Wt6xZ24wpS62n2TCbgAkqxBFR68zd20EVOZsAKEUWpdmXyTLWy6ytP758LWtF62YLs+pwVeqre/omXw+n4+XE8fX+dpweV/aJt'></script>
<script type="text/javascript">
// <![CDATA[
(function() {
try{
  if ( window.external &&'msIsSiteMode' in window.external) {
    if (window.external.msIsSiteMode()) {
      var jl = document.createElement('script');
      jl.type='text/javascript';
      jl.async=true;
      jl.src='/wp-content/plugins/ie-sitemode/custom-jumplist.php';
      var s = document.getElementsByTagName('script')[0];
      s.parentNode.insertBefore(jl, s);
    }
  }
}catch(e){}
})();
// ]]>
</script>	<script type="text/javascript">
	var skimlinks_pub_id = "725X584219"
	var skimlinks_sitename = "countpatients.wordpress.com";
	</script>
	<script type="text/javascript" defer src="https://s.skimresources.com/js/725X1342.skimlinks.js"></script><script>
if ( 'object' === typeof wpcom_mobile_user_agent_info ) {

	wpcom_mobile_user_agent_info.init();
	var mobileStatsQueryString = "";
	
	if( false !== wpcom_mobile_user_agent_info.matchedPlatformName )
		mobileStatsQueryString += "&x_" + 'mobile_platforms' + '=' + wpcom_mobile_user_agent_info.matchedPlatformName;
	
	if( false !== wpcom_mobile_user_agent_info.matchedUserAgentName )
		mobileStatsQueryString += "&x_" + 'mobile_devices' + '=' + wpcom_mobile_user_agent_info.matchedUserAgentName;
	
	if( wpcom_mobile_user_agent_info.isIPad() )
		mobileStatsQueryString += "&x_" + 'ipad_views' + '=' + 'views';

	if( "" != mobileStatsQueryString ) {
		new Image().src = document.location.protocol + '//pixel.wp.com/g.gif?v=wpcom-no-pv' + mobileStatsQueryString + '&baba=' + Math.random();
	}
	
}
</script>
</body>
</html>
